//
//  ViewController.swift
//  TechTest-Infosys
//
//  Created by Stefan Jivalino on 01/12/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

