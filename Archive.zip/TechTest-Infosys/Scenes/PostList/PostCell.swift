//
//  PostCell.swift
//  TechTest-Infosys
//
//  Created by Stefan Jivalino on 01/12/25.
//

import UIKit

class PostCell: UITableViewCell {

    @IBOutlet weak var judulLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
